# SKILLCONNECTCareers
Front-end Website Project for SKILLCONNECT, project using HTML5 , CSS3 , JavaScript , JQuery



## About The Project
SKILLCONNECT is a virtual learning and training platform setup in assistance with SKILLCONNECT to enable students all over India to enhance their knowledge in terms of the job they are going to perform in future. Get in connection with the community of young minds to explore a different version of learning and upskilling
through one of the best virtual platform.
### Home
<img src="../master/img/ss/Screenshot%20(111).png"  width="512" height="256" />

### Intro
<img src="../master/img/ss/Screenshot%20(110).png"  width="512" height="256" />

### Facts
<img src="../master/img/ss/Screenshot%20(109).png"  width="512" height="256" />

### Services
<img src="../master/img/ss/Screenshot%20(108).png"   width="512" height="256" />

### Visit SKILLCONNECT
<img src="../master/img/ss/Screenshot%20(107).png"  width="512" height="256" />

### Internship
<img src="../master/img/ss/Screenshot%20(106).png"  width="512" height="256" />

### Team
<img src="../master/img/ss/Screenshot%20(105).png"  width="512" height="256" />

### Join Us
<img src="../master/img/ss/Screenshot%20(104).png"  width="512" height="256" />

### Contact Us
<img src="../master/img/ss/Screenshot%20(103).png"  width="512" height="256" />

### Registration Form
<img src="../master/img/ss/Screenshot%20(102).png"  width="512" height="256" />
